#include <cstdlib>
#include <iostream>
using namespace std;

class Foo{
 private:
  int dato;
 public:
  // single parameter constructor, can be used as an implicit conversion
  /*explicit*/ Foo (int _dato) : dato (_dato){
    cout << "costruttore specifico, dato="  << dato << endl;    
  }
  /*
    oppure 
    Foo (int _dato){ dato=_dato; }
  */
  int GetDato () { 
      return dato; 
  }
};

void DoBar (Foo myfoo){
  int val = myfoo.GetDato ();
  cout << "dato=" << val << endl;
}

int main(int argc, char *argv[]){
   DoBar (42);          //non pu� essere utilizzata se costruttore "explicit"
   DoBar (Foo (33));
   /*
    L'argomento non � un oggetto Foo, ma un int. 
    Tuttavia, esiste un costruttore per Foo che prende un int:
    questo costruttore pu� essere utilizzato per convertire il parametro per il tipo corretto.
    Anteponendo la parola chiave explicit al costruttore, si impedisce al compilatore di utilizzare 
    quel costruttore per le conversioni implicite. 
    L'aggiunta alla classe precedente creer� un errore di compilazione alla chiamata di funzione Dobar(42). 
    Ora � necessario chiamare per la conversione in modo esplicito con DoBar (Foo (42))
   */
   /*
    Se si dispone di una classe MyString(int size) con un costruttore che costruisce una stringa della dimensione data. 
    Hai una funzione di stampa(const MyString &), e si chiama con stampa(3). 
    Ci si aspetta che la funzioni stampi "3", ma invece stampa una stringa vuota di lunghezza 3.
   */
   system("PAUSE");
   return EXIT_SUCCESS;
}
